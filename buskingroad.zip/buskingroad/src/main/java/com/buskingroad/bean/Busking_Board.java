package com.buskingroad.bean;

public class Busking_Board {
	private String busking_id;

	public Busking_Board(String busking_id) {
		super();
		this.busking_id = busking_id;
	}
	public Busking_Board() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getBusking_id() {
		return busking_id;
	}
	public void setBusking_id(String busking_id) {
		this.busking_id = busking_id;
	}
	
}
