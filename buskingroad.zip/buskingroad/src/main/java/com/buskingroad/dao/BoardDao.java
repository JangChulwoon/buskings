package com.buskingroad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.buskingroad.bean.Busking_Board;
import com.buskingroad.db.DB_TemUpdate;
import com.buskingroad.db.DB_inp;

public class BoardDao {
	private DB_inp dbset = null;

	public BoardDao() {
		this.dbset = new DB_inp();
	}
	static Logger logger = Logger.getLogger(BoardDao.class);

	

	

	public void board_insert(Busking_Board board) {
		insert("insert into busk_board(busking_id) values(?);", board);
	}


	private void insert(final String query, final Busking_Board board) {
		DB_TemUpdate db_tmp = new DB_TemUpdate() {
			@Override
			public PreparedStatement QueryTemplate(Connection conn) throws SQLException {
				PreparedStatement pstmt = conn.prepareStatement(query);
				pstmt.setString(1, board.getBusking_id());
				return pstmt;
			}
		};
		dbset.Template_Update(dbset.dbinit(), db_tmp);
	}

	


}
