package com.buskingroad.bean;

public class Follow {
	private String user_id;
	private String busking_id;

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getBusking_id() {
		return busking_id;
	}

	public void setBusking_id(String busking_id) {
		this.busking_id = busking_id;
	}

	public Follow(String user_id, String busking_id) {
		super();
		this.user_id = user_id;
		this.busking_id = busking_id;
	}

	public Follow() {
		super();
	}

}
