'use strict';
	
if ('serviceWorker' in navigator) {
	
    console.log('Service Worker is supported');
     this.onpush = function(event) {
    	  console.log("data",event.data);
    	  // From here we can write the data to IndexedDB, send it to any open
    	  // windows, display a notification, etc.
    	}
    /**
    navigator.serviceWorker.register('resources/js/sw.js').then(
    	function(serviceWorkerRegistration) {
        console.log(':^)', serviceWorkerRegistration);
        serviceWorkerRegistration.pushManager.subscribe({userVisibleOnly: true}).then(
        	function(pushSubscription) {
	            var point = pushSubscription.endpoint.split('/');
	            console.log('point',pushSubscription.endpoint);
	           // var url = "http://localhost:8080/controller/curl?curl="+point[5];
				// location.href=url;
         
        	});
    	}).catch(function(error) {
	        console.log(':^(', error);
	        //location.reload();  
    });
    
    */
    navigator.serviceWorker.register('resources/js/sw.js').then(
    		  function(serviceWorkerRegistration) {
    		    serviceWorkerRegistration.pushManager.subscribe({userVisibleOnly: true}).then(
    		      function(pushSubscription) {
    		        console.log(pushSubscription.subscriptionId);
    		        console.log(pushSubscription.endpoint);
    		        var point = pushSubscription.endpoint.split('/');
//    		        var url = "http://localhost:8080/controller/curl?curl="+point[5];
//    		        location.href=url;
    		        // The push subscription details needed by the application
    		        // server are now available, and can be sent to it using,
    		        // for example, an XMLHttpRequest.
    		      }, function(error) {
    		        // During development it often helps to log errors to the
    		        // console. In a production environment it might make sense to
    		        // also report information about errors back to the
    		        // application server.
    		        console.log(error);
    		      }
    		    );
    		  });
}
