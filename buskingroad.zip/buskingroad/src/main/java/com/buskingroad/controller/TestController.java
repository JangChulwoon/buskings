package com.buskingroad.controller;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.buskingroad.bean.Token;

@Controller
public class TestController {
	private static final Logger logger = LoggerFactory.getLogger(ServiceworkerController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/curl", method = RequestMethod.GET)
	public String home(Locale locale, Model model, HttpServletRequest request) {
		// test �Դϴ�...
		// curl �������� ..
		String curl = request.getParameter("curl");
		Token token = Token.getInstance();
		token.setMap(12341, curl);
		
		if (curl != null) {
			String query = "curl --header \"Authorization: key=AIzaSyC32sOneKhIyGWzFo3BjoFzSNWaZn44njs\" --header \"Content-Type: application/json\" https://android.googleapis.com/gcm/send -d \"{\\\"registration_ids\\\":[\\\""
					+ curl + "\\\"]}\" ";
			try {
				Runtime.getRuntime().exec(query);
				logger.info(query);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return "success";
	}
}
