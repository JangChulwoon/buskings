package com.buskingroad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.buskingroad.bean.Follow;
import com.buskingroad.db.DB_TemUpdate;
import com.buskingroad.db.DB_inp;

public class FollowDao {
	private DB_inp dbset = null;

	public FollowDao() {
		this.dbset = new DB_inp();
	}
	static Logger logger = Logger.getLogger(FollowDao.class);

	public void user_insert(Follow follow) {
		insert("insert into follow(user_id,busking_id) values(?,?);", follow);
	}


	private void insert(final String query, final Follow follow) {
		DB_TemUpdate db_tmp = new DB_TemUpdate() {
			@Override
			public PreparedStatement QueryTemplate(Connection conn) throws SQLException {
				PreparedStatement pstmt = conn.prepareStatement(query);
				pstmt.setString(1, follow.getUser_id());
				pstmt.setString(2, follow.getBusking_id());
				return pstmt;
			}
		};
		dbset.Template_Update(dbset.dbinit(), db_tmp);
	}
	
	public List<Map<String, String>> getList(String email) {
		StringBuilder strbuild = new StringBuilder("select * from follow where busking_id =");
		strbuild.append("'").append(email).append("'");
		return dbset.getList(strbuild.toString());
	}





}
