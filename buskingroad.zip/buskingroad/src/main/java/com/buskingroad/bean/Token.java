package com.buskingroad.bean;

import java.util.HashMap;
import java.util.Map;

public class Token {
	private volatile static Token token;
	private Map<Integer, String> map = new HashMap<Integer, String>();

	private Token() {
	}

	public static synchronized Token getInstance() {
		if (token == null) {
			synchronized (Token.class) {
				if (token == null) {
					token = new Token();
				}
			}
		}
		return token;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(int key, String token) {
		map.put(key, token);
	}

}
